package uz.zikr.kirish

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Apps {
    data class Target(
        val key: String,
        val title: String,
        val defCount: Int,
        val minCount: Int,
        val defOn: Boolean,
        val packages: Set<String>
    )

    val instagram = Target(
        "instagram", "Instagram", 500, 300, true,
        setOf("com.instagram.android", "com.instagram.lite")
    )
    val telegram = Target(
        "telegram", "Telegram", 100, 100, true,
        setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram")
    )
    val youtube = Target(
        "youtube", "YouTube", 100, 100, false,
        setOf("com.google.android.youtube")
    )
    val tiktok = Target(
        "tiktok", "TikTok", 100, 100, false,
        setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    )
    val facebook = Target(
        "facebook", "Facebook", 100, 100, false,
        setOf("com.facebook.katana", "com.facebook.lite")
    )
    val x = Target(
        "x", "X (Twitter)", 100, 100, false,
        setOf("com.twitter.android")
    )
    val all = listOf(instagram, telegram, youtube, tiktok, facebook, x)

    fun byPackage(pkg: String): Target? = all.firstOrNull { pkg in it.packages }
}

data class Zikr(val latin: String, val arabic: String)

object Zikrs {
    val all = listOf(
        Zikr("Astag‘firulloh", "أَسْتَغْفِرُ اللّٰهَ"),
        Zikr("Subhanalloh", "سُبْحَانَ اللّٰهِ"),
        Zikr("Alhamdulillah", "اَلْحَمْدُ لِلّٰهِ"),
        Zikr("Allohu akbar", "اَللّٰهُ أَكْبَرُ"),
        Zikr("La ilaha illalloh", "لَا إِلٰهَ إِلَّا اللّٰهُ")
    )
}

object Hikmat {
    private val list = listOf(
        "Kichik odat — katta o‘zgarish. Bugun o‘zingizni yengdingiz.",
        "Nafsni jilovlash — eng katta kuch.",
        "Har bir zikr qalbga sokinlik olib keladi.",
        "Vaqt — omonat. Uni ongli sarflang.",
        "Intizom — erkinlik kalitidir.",
        "To‘xtab, o‘ylab kirish — ongli hayotning boshlanishi."
    )

    fun random(): String = list.random()
}

object Prefs {
    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("zikr_prefs", Context.MODE_PRIVATE)

    fun enabled(c: Context, t: Apps.Target): Boolean = sp(c).getBoolean("en_" + t.key, t.defOn)
    fun setEnabled(c: Context, t: Apps.Target, v: Boolean) {
        sp(c).edit().putBoolean("en_" + t.key, v).apply()
    }

    fun count(c: Context, t: Apps.Target): Int =
        sp(c).getInt("cnt_" + t.key, t.defCount).coerceAtLeast(t.minCount)
    fun setCount(c: Context, t: Apps.Target, v: Int) {
        sp(c).edit().putInt("cnt_" + t.key, v.coerceAtLeast(t.minCount)).apply()
    }

    fun zikrIdx(c: Context): Int =
        sp(c).getInt("zikr", 0).coerceIn(0, Zikrs.all.size - 1)

    fun setZikr(c: Context, i: Int) {
        sp(c).edit().putInt("zikr", i).apply()
    }

    fun bgOn(c: Context): Boolean = sp(c).getBoolean("bg_on", true)
    fun setBgOn(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("bg_on", v).apply()
    }

    fun dark(c: Context): Boolean = sp(c).getBoolean("dark", true)
    fun setDark(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("dark", v).apply()
    }

    fun accent(c: Context): Int = sp(c).getInt("accent", 0)
    fun setAccent(c: Context, v: Int) {
        sp(c).edit().putInt("accent", v).apply()
    }
}

/** Foydalanuvchi galereyadan tanlagan fon rasmlari (ilovaning ichki xotirasida). */
object BgStore {
    private fun dir(c: Context): File = File(c.filesDir, "bg").apply { mkdirs() }

    fun files(c: Context): List<File> =
        dir(c).listFiles { f -> f.extension == "jpg" }?.sortedBy { it.name } ?: emptyList()

    fun importAll(c: Context, uris: List<Uri>) {
        val d = dir(c)
        var room = 30 - files(c).size
        for (u in uris) {
            if (room <= 0) break
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = c.contentResolver.openInputStream(u)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                } ?: continue
                val orient = try {
                    c.contentResolver.openInputStream(u)?.use {
                        ExifInterface(it).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                        )
                    } ?: ExifInterface.ORIENTATION_NORMAL
                } catch (_: Exception) {
                    ExifInterface.ORIENTATION_NORMAL
                }
                val deg = when (orient) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                val out = if (deg != 0f) {
                    Bitmap.createBitmap(
                        bmp, 0, 0, bmp.width, bmp.height,
                        Matrix().apply { postRotate(deg) }, true
                    )
                } else {
                    bmp
                }
                val f = File(d, "u_" + System.currentTimeMillis() + "_" + room + ".jpg")
                f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                room--
            } catch (_: Throwable) {
            }
        }
    }

    fun clear(c: Context) {
        files(c).forEach { it.delete() }
    }
}

/** Xotiradagi holat: hozir qaysi ilovaga ruxsat berilgan. */
object Guard {
    @Volatile var granted: String? = null
    @Volatile var lastLaunch: Long = 0L
}

data class Row(
    val day: String,
    val key: String,
    val opens: Int,
    val attempts: Int,
    val zikr: Int
)

class Db private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx, "zikr.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE attempts(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "pkg TEXT NOT NULL," +
                "day TEXT NOT NULL," +
                "started INTEGER NOT NULL," +
                "target INTEGER NOT NULL," +
                "count INTEGER NOT NULL DEFAULT 0," +
                "completed INTEGER NOT NULL DEFAULT 0)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun start(key: String, target: Int): Long {
        val v = ContentValues().apply {
            put("pkg", key)
            put("day", today())
            put("started", System.currentTimeMillis())
            put("target", target)
            put("count", 0)
            put("completed", 0)
        }
        return writableDatabase.insert("attempts", null, v)
    }

    fun setCount(id: Long, count: Int, completed: Boolean) {
        val v = ContentValues().apply {
            put("count", count)
            put("completed", if (completed) 1 else 0)
        }
        writableDatabase.update("attempts", v, "id=?", arrayOf(id.toString()))
    }

    fun daily(): List<Row> {
        val out = ArrayList<Row>()
        readableDatabase.rawQuery(
            "SELECT day, pkg, SUM(completed), COUNT(*), SUM(count) " +
                "FROM attempts GROUP BY day, pkg ORDER BY day DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Row(c.getString(0), c.getString(1), c.getInt(2), c.getInt(3), c.getInt(4)))
            }
        }
        return out
    }

    companion object {
        @Volatile private var inst: Db? = null

        fun get(c: Context): Db =
            inst ?: synchronized(this) {
                inst ?: Db(c.applicationContext).also { inst = it }
            }

        fun today(): String =
            SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
}
