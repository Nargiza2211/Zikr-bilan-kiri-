package uz.zikr.kirish

import android.content.Context
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

object Palette {
    var dark by mutableStateOf(true)
    var accentIdx by mutableIntStateOf(0)
    val accents = listOf(
        Color(0xFF3DDC97), Color(0xFF5AA9FF), Color(0xFFB388FF),
        Color(0xFFFFB74D), Color(0xFFFF7A90)
    )

    fun load(c: Context) {
        dark = Prefs.dark(c)
        accentIdx = Prefs.accent(c)
    }
}

val Bg: Color get() = if (Palette.dark) Color(0xFF0B1F1A) else Color(0xFFF1F6F3)
val CardBg: Color get() = if (Palette.dark) Color(0xFF132B25) else Color(0xFFFFFFFF)
val TextMain: Color get() = if (Palette.dark) Color(0xFFE8F5F0) else Color(0xFF10231D)
val Muted: Color get() = if (Palette.dark) Color(0xFF8FB3A6) else Color(0xFF5C7A6E)
val Accent: Color
    get() = Palette.accents[Palette.accentIdx.coerceIn(0, Palette.accents.size - 1)]

@Composable
fun ZikrTheme(content: @Composable () -> Unit) {
    val scheme = if (Palette.dark) {
        darkColorScheme(
            primary = Accent, onPrimary = Color(0xFF06130F),
            background = Bg, surface = CardBg
        )
    } else {
        lightColorScheme(
            primary = Accent, onPrimary = Color(0xFF06130F),
            background = Bg, surface = CardBg
        )
    }
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = Bg, contentColor = TextMain) {
            content()
        }
    }
}

/** Zikr oynasi uchun o'zgaruvchi fonlar: har safar boshqasi chiqadi. */
val Gradients: List<List<Color>> = listOf(
    listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)),
    listOf(Color(0xFF0B3D2E), Color(0xFF14594A), Color(0xFF1B7A5C)),
    listOf(Color(0xFF1B1035), Color(0xFF3A2A6B), Color(0xFF5B3F8F)),
    listOf(Color(0xFF0A1931), Color(0xFF185ADB), Color(0xFF1F4287)),
    listOf(Color(0xFF3B1C32), Color(0xFF6A1F4B), Color(0xFF9B3A62)),
    listOf(Color(0xFF2B1B0E), Color(0xFF6B3A1C), Color(0xFFB0662A)),
    listOf(Color(0xFF021B1A), Color(0xFF0E5E5A), Color(0xFF2AA198)),
    listOf(Color(0xFF16222A), Color(0xFF3A6073), Color(0xFF5C8DA6))
)

private val Gold = Color(0xFFF4CF78)

private fun squarePath(c: Offset, r: Float, rotDeg: Double): Path {
    val p = Path()
    for (i in 0 until 4) {
        val a = Math.toRadians(rotDeg + 45.0 + i * 90.0)
        val x = c.x + (r * cos(a)).toFloat()
        val y = c.y + (r * sin(a)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

/** Oltin hoshiyali tasbeh tugmasi: raqam tugmaning o'zida. */
@Composable
fun GoldTasbeh(count: Int, total: Int, onTap: () -> Unit) {
    val view = LocalView.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    Box(
        modifier = Modifier
            .size(300.dp)
            .scale(if (pressed) 0.95f else 1f)
            .clip(CircleShape)
            .clickable(interactionSource = src, indication = null) {
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onTap()
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val s = size.minDimension / 2f
            val ringR = s * 0.93f
            val sw = s * 0.03f
            drawCircle(
                color = Color(0x33FFFFFF), radius = ringR, center = c,
                style = Stroke(width = sw)
            )
            val sweep = 360f * (count / total.toFloat()).coerceIn(0f, 1f)
            drawArc(
                color = Gold, startAngle = -90f, sweepAngle = sweep, useCenter = false,
                topLeft = Offset(c.x - ringR, c.y - ringR),
                size = Size(ringR * 2f, ringR * 2f),
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
            val rimR = s * 0.80f
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(
                        Gold, Color(0xFF7A541E), Color(0xFFFFE9A0),
                        Color(0xFF7A541E), Gold
                    ),
                    center = c
                ),
                radius = rimR, center = c
            )
            val discR = s * 0.73f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF16342C), Color(0xFF060F0D)),
                    center = c, radius = discR
                ),
                radius = discR, center = c
            )
            val thin = Stroke(width = s * 0.008f)
            drawPath(squarePath(c, discR * 0.86f, 0.0), Color(0x59F4CF78), style = thin)
            drawPath(squarePath(c, discR * 0.86f, 45.0), Color(0x59F4CF78), style = thin)
            drawCircle(color = Color(0x3DF4CF78), radius = discR * 0.86f, center = c, style = thin)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "$count",
                color = Gold,
                fontSize = 76.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif
            )
            Text(
                "/ $total",
                color = Gold.copy(alpha = 0.8f),
                fontSize = 18.sp,
                fontFamily = FontFamily.Serif
            )
        }
    }
}

@Composable
fun ZikrScreen(
    title: String,
    zikr: Zikr,
    total: Int,
    count: Int,
    msg: String?,
    bg: Int,
    image: ImageBitmap?,
    onTap: () -> Unit,
    onBack: () -> Unit
) {
    val view = LocalView.current
    val grad = if (image == null) Gradients.getOrNull(bg) else null
    val fancy = image != null || grad != null
    val fg = if (fancy) Color(0xFFF2FFF9) else TextMain
    val sub = if (fancy) Color(0xCCFFFFFF) else Muted
    val track = if (fancy) Color(0x33FFFFFF) else CardBg
    val backdrop = if (grad != null) {
        Brush.verticalGradient(grad)
    } else {
        Brush.verticalGradient(listOf(Bg, Bg))
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(backdrop)
    ) {
        if (image != null) {
            Image(
                bitmap = image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x73000000))
            )
        }
        TextButton(
            onClick = onBack,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) {
            Text("← Orqaga", color = sub, fontSize = 16.sp)
        }

        if (msg != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("✅", fontSize = 64.sp)
                Spacer(Modifier.height(16.dp))
                Text(
                    "Barakalla!",
                    color = Accent, fontSize = 32.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    msg,
                    color = fg, fontSize = 18.sp, textAlign = TextAlign.Center
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(title, color = sub, fontSize = 16.sp)
                Spacer(Modifier.height(16.dp))
                Text(zikr.arabic, color = Gold, fontSize = 34.sp)
                Text(
                    zikr.latin,
                    color = fg,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(36.dp))
                GoldTasbeh(count = count, total = total, onTap = onTap)
            }
        }
    }
}
