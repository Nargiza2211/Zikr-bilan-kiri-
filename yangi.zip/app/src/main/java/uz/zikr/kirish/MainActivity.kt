package uz.zikr.kirish

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    private val picker = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            Thread {
                BgStore.importAll(this, uris)
                runOnUiThread { tick++ }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Palette.load(this)
        setContent { ZikrTheme { Home(this, tick) { picker.launch("image/*") } } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

private val dayNames = listOf("Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya")

fun isAccessibilityOn(ctx: Context): Boolean {
    val me = ComponentName(ctx, GuardService::class.java)
    val s = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return s.split(':').any { ComponentName.unflattenFromString(it) == me }
}

private fun openSettings(ctx: Context, action: String, withPkg: Boolean = false) {
    val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (withPkg) i.data = Uri.parse("package:${ctx.packageName}")
    try {
        ctx.startActivity(i)
    } catch (_: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun fmtDay(d: String): String {
    val p = d.split("-")
    return if (p.size == 3) "${p[2]}.${p[1]}.${p[0]}" else d
}

private fun calcStreak(days: Set<String>): Int {
    var d = LocalDate.now()
    if (d.toString() !in days) d = d.minusDays(1)
    var n = 0
    while (d.toString() in days) {
        n++
        d = d.minusDays(1)
    }
    return n
}

private fun stepCount(c: Int, up: Boolean, min: Int): Int {
    val s = if (c > 100 || (c == 100 && up)) 50 else 10
    return if (up) minOf(c + s, 5000) else maxOf(c - s, min)
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardBg)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Step(ok: Boolean, title: String, hint: String, btn: String, onClick: () -> Unit) {
    Text(
        (if (ok) "✅ " else "⚠️ ") + title,
        color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.SemiBold
    )
    Text(hint, color = Muted, fontSize = 13.sp)
    if (!ok) {
        Spacer(Modifier.height(6.dp))
        Button(onClick = onClick) { Text(btn) }
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
fun SettingsPanel(ctx: Context, ver: Int, tick: Int, onPick: () -> Unit, onChange: () -> Unit) {
    val zIdx = remember(ver) { Prefs.zikrIdx(ctx) }
    Panel {
        Text("Zikr turi", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Zikrs.all.forEachIndexed { i, z ->
            Text(
                (if (i == zIdx) "● " else "○ ") + z.latin,
                color = if (i == zIdx) Accent else Muted,
                fontSize = 16.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        Prefs.setZikr(ctx, i)
                        onChange()
                    }
                    .padding(vertical = 8.dp)
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Ilovalar va zikr soni",
            color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp
        )
        Apps.all.forEach { t ->
            val on = remember(ver) { Prefs.enabled(ctx, t) }
            val c = remember(ver) { Prefs.count(ctx, t) }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Switch(
                    checked = on,
                    onCheckedChange = {
                        Prefs.setEnabled(ctx, t, it)
                        onChange()
                    }
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    t.title + " (kamida ${t.minCount})",
                    color = TextMain,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    Prefs.setCount(ctx, t, stepCount(c, false, t.minCount))
                    onChange()
                }) { Text("−", fontSize = 20.sp) }
                Text("$c", color = TextMain, fontWeight = FontWeight.Bold)
                TextButton(onClick = {
                    Prefs.setCount(ctx, t, stepCount(c, true, t.minCount))
                    onChange()
                }) { Text("+", fontSize = 20.sp) }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Mavzu", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Qorong‘i rejim", color = TextMain, modifier = Modifier.weight(1f))
            Switch(
                checked = Palette.dark,
                onCheckedChange = {
                    Palette.dark = it
                    Prefs.setDark(ctx, it)
                    onChange()
                }
            )
        }
        val bgOn = remember(ver) { Prefs.bgOn(ctx) }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("O‘zgaruvchi fon (zikr oynasida)", color = TextMain, modifier = Modifier.weight(1f))
            Switch(
                checked = bgOn,
                onCheckedChange = {
                    Prefs.setBgOn(ctx, it)
                    onChange()
                }
            )
        }
        val nPics = remember(ver, tick) { BgStore.files(ctx).size }
        Spacer(Modifier.height(8.dp))
        Text(
            if (nPics == 0) "Hozir ilovaning tayyor rasmlari ishlatilmoqda."
            else "Sizning $nPics ta rasmingiz ishlatilmoqda.",
            color = Muted, fontSize = 13.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onPick) { Text("Rasm qo‘shish") }
            if (nPics > 0) {
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = {
                    BgStore.clear(ctx)
                    onChange()
                }) { Text("Rasmlarimni o‘chirish") }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row {
            Palette.accents.forEachIndexed { i, col ->
                Box(
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(col)
                        .clickable {
                            Palette.accentIdx = i
                            Prefs.setAccent(ctx, i)
                            onChange()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (i == Palette.accentIdx) {
                        Text("✓", color = Color(0xFF06130F), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun Home(ctx: Context, tick: Int, onPick: () -> Unit) {
    val rows = remember(tick) { Db.get(ctx).daily() }
    val accOn = remember(tick) { isAccessibilityOn(ctx) }
    val overlayOn = remember(tick) { Settings.canDrawOverlays(ctx) }
    var ver by remember { mutableIntStateOf(0) }
    val enabledApps = remember(tick, ver) { Apps.all.filter { Prefs.enabled(ctx, it) } }
    val zikr = remember(tick, ver) { Zikrs.all[Prefs.zikrIdx(ctx)] }
    val today = Db.today()
    val days = rows.groupBy { it.day }
    val dayTotals = days.mapValues { e -> e.value.sumOf { it.zikr } }
    val streak = calcStreak(dayTotals.filterValues { it > 0 }.keys)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Zikr bilan kirish", color = TextMain, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            val sub = if (enabledApps.isEmpty()) {
                "Hech qaysi ilova tanlanmagan."
            } else {
                enabledApps.joinToString(", ") { "${it.title} — ${Prefs.count(ctx, it)}" } +
                    " marta «${zikr.latin}»."
            }
            Text(sub, color = Muted, fontSize = 14.sp)
        }

        item {
            Panel {
                Text(
                    "🔥 Ketma-ket kunlar: $streak",
                    color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Bold
                )
                if (streak == 0) {
                    Text("Bugun zikr qilib, seriyani boshlang.", color = Muted, fontSize = 13.sp)
                }
            }
        }

        item {
            Panel {
                Step(
                    accOn, "Maxsus imkoniyatlar (Accessibility)",
                    "Faqat tanlangan ilovalar ochilganini bilish uchun. Matn va xabarlar o‘qilmaydi.",
                    "Yoqish"
                ) { openSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
                Step(
                    overlayOn, "Boshqa ilovalar ustida ko‘rsatish",
                    "Ixtiyoriy. Ba’zi telefonlarda berib bo‘lmaydi.",
                    "Ruxsat berish"
                ) { openSettings(ctx, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }
                Step(
                    false, "Ilova sozlamalari",
                    "«Cheklangan sozlamalarga ruxsat» (⋮ menyu), Avtoyurgizish, Batareya: «Cheklovsiz».",
                    "Ilova sozlamalarini ochish"
                ) { openSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true) }
            }
        }

        item {
            val week = (6 downTo 0).map { LocalDate.now().minusDays(it.toLong()) }
            val vals = week.map { dayTotals[it.toString()] ?: 0 }
            val maxV = maxOf(vals.maxOrNull() ?: 0, 1)
            Panel {
                Text("Oxirgi 7 kun", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    week.forEachIndexed { i, d ->
                        val v = vals[i]
                        Column(
                            modifier = Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            Text(if (v > 0) "$v" else "", color = Muted, fontSize = 10.sp)
                            Box(
                                modifier = Modifier
                                    .width(22.dp)
                                    .height(maxOf((v / maxV.toFloat() * 80f).dp, 3.dp))
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (v > 0) Accent else Muted.copy(alpha = 0.25f))
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(dayNames[d.dayOfWeek.value - 1], color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        item { Text("Bugun", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
        items(enabledApps) { t ->
            val r = rows.firstOrNull { it.day == today && it.key == t.key }
            val all = rows.filter { it.key == t.key }.sumOf { it.zikr }
            Panel {
                Text(t.title, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Ochilgan: ${r?.opens ?: 0} marta", color = Muted)
                Text(
                    "Urinishlar: ${r?.attempts ?: 0} (tugallanmagan: ${(r?.attempts ?: 0) - (r?.opens ?: 0)})",
                    color = Muted
                )
                Text("Bugungi zikr: ${r?.zikr ?: 0}", color = Accent)
                Text("Barcha kunlar bo‘yicha: $all", color = Muted)
            }
        }
        item {
            val todayTotal = rows.filter { it.day == today }.sumOf { it.zikr }
            val allTotal = rows.sumOf { it.zikr }
            Panel {
                Text(
                    "Bugungi jami zikr: $todayTotal",
                    color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Text("Umumiy zikr: $allTotal", color = Muted)
            }
        }

        item { Text("Sozlamalar", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
        item { SettingsPanel(ctx, ver, tick, onPick) { ver++ } }

        item { Text("Tarix", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
        if (days.isEmpty()) {
            item { Text("Hozircha tarix yo‘q.", color = Muted) }
        }
        items(days.keys.toList()) { d ->
            val list = days[d].orEmpty()
            Panel {
                Text(fmtDay(d), color = TextMain, fontWeight = FontWeight.Bold)
                Apps.all.forEach { t ->
                    val r = list.firstOrNull { it.key == t.key }
                    if (r != null) {
                        Text(
                            "${t.title} — ${r.opens} marta, ${r.zikr} zikr (urinish: ${r.attempts})",
                            color = Muted
                        )
                    }
                }
                Text("Jami — ${list.sumOf { it.zikr }} zikr", color = Accent)
            }
        }
    }
}
