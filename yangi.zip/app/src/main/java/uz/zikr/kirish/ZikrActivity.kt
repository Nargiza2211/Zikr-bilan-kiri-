package uz.zikr.kirish

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.random.Random

private val BuiltIn = intArrayOf(
    R.drawable.bg_1, R.drawable.bg_2, R.drawable.bg_3, R.drawable.bg_4,
    R.drawable.bg_5, R.drawable.bg_6, R.drawable.bg_7, R.drawable.bg_8
)

class ZikrActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PKG = "pkg"
    }

    private var target by mutableStateOf<Apps.Target?>(null)
    private var zikr by mutableStateOf(Zikrs.all[0])
    private var total by mutableIntStateOf(1)
    private var count by mutableIntStateOf(0)
    private var msg by mutableStateOf<String?>(null)
    private var bgIdx by mutableIntStateOf(-1)
    private var bgImage by mutableStateOf<ImageBitmap?>(null)
    private var lastPick = -1
    private var pkg = ""
    private var attemptId = -1L
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Palette.load(this)
        onBackPressedDispatcher.addCallback(this) { goHome() }
        begin(intent)
        setContent {
            ZikrTheme {
                val t = target
                if (t != null) {
                    ZikrScreen(
                        title = t.title,
                        zikr = zikr,
                        total = total,
                        count = count,
                        msg = msg,
                        bg = bgIdx,
                        image = bgImage,
                        onTap = { tap() },
                        onBack = { goHome() }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        begin(intent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    /** Yangi urinish: har doim 0 dan boshlanadi. Eskisi tugallanmagan bo'lib tarixda qoladi. */
    private fun begin(i: Intent?) {
        if (msg != null) return
        val p = i?.getStringExtra(EXTRA_PKG)
        val t = p?.let { Apps.byPackage(it) }
        if (p == null || t == null) {
            finish()
            return
        }
        pkg = p
        if (t == target && count == 0) return
        target = t
        zikr = Zikrs.all[Prefs.zikrIdx(this)]
        total = Prefs.count(this, t).coerceAtLeast(1)
        count = 0
        pickBackground()
        attemptId = Db.get(this).start(t.key, total)
    }

    private fun pickBackground() {
        if (!Prefs.bgOn(this)) {
            bgIdx = -1
            bgImage = null
            return
        }
        val mine = BgStore.files(this)
        val n = if (mine.isNotEmpty()) mine.size else BuiltIn.size
        var i = Random.nextInt(n)
        if (n > 1 && i == lastPick) i = (i + 1) % n
        lastPick = i
        bgIdx = i % Gradients.size
        bgImage = try {
            if (mine.isNotEmpty()) {
                BitmapFactory.decodeFile(mine[i].path)?.asImageBitmap()
            } else {
                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                BitmapFactory.decodeResource(resources, BuiltIn[i], o)?.asImageBitmap()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun tap() {
        if (target == null || msg != null) return
        count++
        val done = count >= total
        Db.get(this).setCount(attemptId, count, done)
        if (done) {
            Guard.granted = pkg
            msg = Hikmat.random()
            handler.postDelayed({ openTarget() }, 2200)
        }
    }

    private fun openTarget() {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        }
        finish()
    }

    private fun goHome() {
        handler.removeCallbacksAndMessages(null)
        val home = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(home)
        finish()
    }
}
