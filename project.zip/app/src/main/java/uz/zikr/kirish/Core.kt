package uz.zikr.kirish

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Apps {
    data class Target(
        val key: String,
        val title: String,
        val count: Int,
        val packages: Set<String>
    )

    val instagram = Target(
        "instagram", "Instagram", 500,
        setOf("com.instagram.android", "com.instagram.lite")
    )
    val telegram = Target(
        "telegram", "Telegram", 100,
        setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram")
    )
    val all = listOf(instagram, telegram)

    fun byPackage(pkg: String): Target? = all.firstOrNull { pkg in it.packages }
}

/** Xotiradagi holat: hozir qaysi ilovaga ruxsat berilgan. */
object Guard {
    @Volatile var granted: String? = null
    @Volatile var lastLaunch: Long = 0L
}

data class Row(
    val day: String,
    val key: String,
    val opens: Int,
    val attempts: Int,
    val zikr: Int
)

class Db private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx, "zikr.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE attempts(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "pkg TEXT NOT NULL," +
                "day TEXT NOT NULL," +
                "started INTEGER NOT NULL," +
                "target INTEGER NOT NULL," +
                "count INTEGER NOT NULL DEFAULT 0," +
                "completed INTEGER NOT NULL DEFAULT 0)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun start(key: String, target: Int): Long {
        val v = ContentValues().apply {
            put("pkg", key)
            put("day", today())
            put("started", System.currentTimeMillis())
            put("target", target)
            put("count", 0)
            put("completed", 0)
        }
        return writableDatabase.insert("attempts", null, v)
    }

    fun setCount(id: Long, count: Int, completed: Boolean) {
        val v = ContentValues().apply {
            put("count", count)
            put("completed", if (completed) 1 else 0)
        }
        writableDatabase.update("attempts", v, "id=?", arrayOf(id.toString()))
    }

    fun daily(): List<Row> {
        val out = ArrayList<Row>()
        readableDatabase.rawQuery(
            "SELECT day, pkg, SUM(completed), COUNT(*), SUM(count) " +
                "FROM attempts GROUP BY day, pkg ORDER BY day DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Row(c.getString(0), c.getString(1), c.getInt(2), c.getInt(3), c.getInt(4)))
            }
        }
        return out
    }

    companion object {
        @Volatile private var inst: Db? = null

        fun get(c: Context): Db =
            inst ?: synchronized(this) {
                inst ?: Db(c.applicationContext).also { inst = it }
            }

        fun today(): String =
            SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
}
