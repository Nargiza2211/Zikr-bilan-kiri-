package uz.zikr.kirish

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF0B1F1A)
val CardBg = Color(0xFF132B25)
val Accent = Color(0xFF3DDC97)
val TextMain = Color(0xFFE8F5F0)
val Muted = Color(0xFF8FB3A6)

@Composable
fun ZikrTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Bg,
            background = Bg,
            surface = CardBg
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg, contentColor = TextMain) {
            content()
        }
    }
}

@Composable
fun ZikrScreen(
    title: String,
    total: Int,
    count: Int,
    onTap: () -> Unit,
    onBack: () -> Unit
) {
    val view = LocalView.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1F1A), Color(0xFF05100D))))
    ) {
        TextButton(
            onClick = onBack,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) {
            Text("← Orqaga", color = Muted, fontSize = 16.sp)
        }

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(title, color = Muted, fontSize = 16.sp)
            Spacer(Modifier.height(16.dp))
            Text("أَسْتَغْفِرُ اللّٰهَ", color = Accent, fontSize = 34.sp)
            Text(
                "Astag‘firulloh",
                color = TextMain,
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "$count/$total",
                color = TextMain,
                fontSize = 56.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(24.dp))
            Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { (count / total.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(),
                    color = Accent,
                    trackColor = CardBg,
                    strokeWidth = 10.dp
                )
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .clip(CircleShape)
                        .background(Accent)
                        .clickable {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            onTap()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text("Bos", color = Bg, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
