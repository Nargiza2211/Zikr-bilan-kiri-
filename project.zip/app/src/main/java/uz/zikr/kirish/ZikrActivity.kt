package uz.zikr.kirish

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class ZikrActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PKG = "pkg"
    }

    private var target by mutableStateOf<Apps.Target?>(null)
    private var count by mutableIntStateOf(0)
    private var pkg = ""
    private var attemptId = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this) { goHome() }
        begin(intent)
        setContent {
            ZikrTheme {
                val t = target
                if (t != null) {
                    ZikrScreen(
                        title = t.title,
                        total = t.count,
                        count = count,
                        onTap = { tap() },
                        onBack = { goHome() }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        begin(intent)
    }

    /** Yangi urinish: har doim 0 dan boshlanadi. Eskisi tugallanmagan bo'lib tarixda qoladi. */
    private fun begin(i: Intent?) {
        val p = i?.getStringExtra(EXTRA_PKG)
        val t = p?.let { Apps.byPackage(it) }
        if (p == null || t == null) {
            finish()
            return
        }
        pkg = p
        if (t == target && count == 0) return
        target = t
        count = 0
        attemptId = Db.get(this).start(t.key, t.count)
    }

    private fun tap() {
        val t = target ?: return
        count++
        val done = count >= t.count
        Db.get(this).setCount(attemptId, count, done)
        if (done) {
            Guard.granted = pkg
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
            }
            finish()
        }
    }

    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(home)
        finish()
    }
}
