package uz.zikr.kirish

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZikrTheme { Home(this, tick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

fun isAccessibilityOn(ctx: Context): Boolean {
    val me = ComponentName(ctx, GuardService::class.java)
    val s = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return s.split(':').any { ComponentName.unflattenFromString(it) == me }
}

private fun openSettings(ctx: Context, action: String, withPkg: Boolean = false) {
    val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (withPkg) i.data = Uri.parse("package:${ctx.packageName}")
    try {
        ctx.startActivity(i)
    } catch (_: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun fmtDay(d: String): String {
    val p = d.split("-")
    return if (p.size == 3) "${p[2]}.${p[1]}.${p[0]}" else d
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardBg)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Step(ok: Boolean, title: String, hint: String, btn: String, onClick: () -> Unit) {
    Text(
        (if (ok) "✅ " else "⚠️ ") + title,
        color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.SemiBold
    )
    Text(hint, color = Muted, fontSize = 13.sp)
    if (!ok) {
        Spacer(Modifier.height(6.dp))
        Button(onClick = onClick) { Text(btn) }
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
fun Home(ctx: Context, tick: Int) {
    val rows = remember(tick) { Db.get(ctx).daily() }
    val accOn = remember(tick) { isAccessibilityOn(ctx) }
    val overlayOn = remember(tick) { Settings.canDrawOverlays(ctx) }
    val today = Db.today()
    val days = rows.groupBy { it.day }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Zikr bilan kirish", color = TextMain, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                "Instagram — 500, Telegram — 100 marta «Astag‘firulloh».",
                color = Muted, fontSize = 14.sp
            )
        }

        item {
            Panel {
                Step(
                    accOn, "Maxsus imkoniyatlar (Accessibility)",
                    "Faqat Instagram/Telegram ochilganini bilish uchun. Matn va xabarlar o‘qilmaydi.",
                    "Yoqish"
                ) { openSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
                Step(
                    overlayOn, "Boshqa ilovalar ustida ko‘rsatish",
                    "Zikr oynasi ilova ustida chiqishi uchun.",
                    "Ruxsat berish"
                ) { openSettings(ctx, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }
                Step(
                    false, "Ilova sozlamalari",
                    "«Cheklangan sozlamalarga ruxsat» (⋮ menyu), Avtoyurgizish, Batareya: «Cheklovsiz».",
                    "Ilova sozlamalarini ochish"
                ) { openSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true) }
            }
        }

        item { Text("Bugun", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
        items(Apps.all) { t ->
            val r = rows.firstOrNull { it.day == today && it.key == t.key }
            val all = rows.filter { it.key == t.key }.sumOf { it.zikr }
            Panel {
                Text(t.title, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Ochilgan: ${r?.opens ?: 0} marta", color = Muted)
                Text("Urinishlar: ${r?.attempts ?: 0} (tugallanmagan: ${(r?.attempts ?: 0) - (r?.opens ?: 0)})", color = Muted)
                Text("Bugungi zikr: ${r?.zikr ?: 0}", color = Accent)
                Text("Barcha kunlar bo‘yicha: $all", color = Muted)
            }
        }
        item {
            val todayTotal = rows.filter { it.day == today }.sumOf { it.zikr }
            val allTotal = rows.sumOf { it.zikr }
            Panel {
                Text("Bugungi jami zikr: $todayTotal", color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Umumiy zikr: $allTotal", color = Muted)
            }
        }

        item { Text("Tarix", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
        if (days.isEmpty()) {
            item { Text("Hozircha tarix yo‘q.", color = Muted) }
        }
        items(days.keys.toList()) { d ->
            val list = days[d].orEmpty()
            Panel {
                Text(fmtDay(d), color = TextMain, fontWeight = FontWeight.Bold)
                Apps.all.forEach { t ->
                    val r = list.firstOrNull { it.key == t.key }
                    if (r != null) {
                        Text("${t.title} — ${r.opens} marta, ${r.zikr} zikr (urinish: ${r.attempts})", color = Muted)
                    }
                }
                Text("Jami — ${list.sumOf { it.zikr }} zikr", color = Accent)
            }
        }
    }
}
