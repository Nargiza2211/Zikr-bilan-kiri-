package uz.zikr.kirish

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Faqat oyna o'zgarganini (qaysi paket) kuzatadi.
 * Ekran matnini, xabarlarni o'qimaydi (canRetrieveWindowContent = false).
 */
class GuardService : AccessibilityService() {

    private val ignored = setOf(
        "android",
        "com.android.systemui",
        "com.miui.securitycenter",
        "com.lbe.security.miui",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        Guard.serviceCtx = this
    }

    override fun onDestroy() {
        if (Guard.serviceCtx === this) Guard.serviceCtx = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val l = pkg.lowercase()
        val ignorable = pkg in ignored || l.contains("inputmethod") || l.contains("keyboard")
        val target = Apps.byPackage(pkg)
        if (target == null || !Prefs.enabled(this, target)) {
            if (ignorable) return
            Guard.current = pkg
            Guard.granted = null
            return
        }

        Guard.current = pkg
        if (Guard.granted == pkg || Guard.inFree(pkg)) return

        val now = SystemClock.elapsedRealtime()
        if (now - Guard.lastLaunch < 700) return
        Guard.lastLaunch = now
        Guard.granted = null

        val i = Intent(this, ZikrActivity::class.java)
            .putExtra(ZikrActivity.EXTRA_PKG, pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {}
}
